if( window.console == undefined ){ console = { log : function(){} }; }


$(function(){

/*  bxSlider 기본세팅
	$('.mainSubSlideBox ul').bxSlider({
		auto: true,
		autoControls: true,
		onSlideAfter: function(){
			 setTimeout(function(){
				$('.mainSubSlideBox .bx-start').trigger('click');
			 },1000);
		  }
	});
*/

});



$(window).load(function() {

/* flexslider 기본세팅
	$('.flexslider').flexslider({
		animation: "slide",
		after: function(slider) {
			if (!slider.playing) {
			 slider.play();
			}
		}
	});
*/

/* 스와이프 슬라이드 기본세팅
var swiper = new Swiper('.swiper-containerMain', {
	pagination: '.swiper-paginationMain',
	//nextButton: '.swiper-button-next',
   // prevButton: '.swiper-button-prev',
	paginationClickable: true,
	//spaceBetween: 30,
	centeredSlides: true,
	autoplay: 4000,
	autoplayDisableOnInteraction: false
*/


});